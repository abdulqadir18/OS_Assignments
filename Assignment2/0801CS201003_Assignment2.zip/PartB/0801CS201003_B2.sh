#!/bin/sh
s=$1$2
echo $s