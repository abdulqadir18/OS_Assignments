#!/bin/sh
echo "This is my first bash script"
date_now=$(date +'%m:%d:%Y')
time_now=$(date +'%H:%M:%S')
echo "Today's date is : $date_now"
echo "Time now is : $time_now"